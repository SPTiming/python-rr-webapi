"""
Event API endpoint modules
""" 